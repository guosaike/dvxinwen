<template>
  <el-button type="primary" @click="visible = true">添加地址</el-button>
  <el-card shadow="never" style="margin-top: 10px;">

    <!-- 查询区域 -->
    <el-card shadow="never" style="margin: 10px 0;">
      <el-form :model="search">
        <el-row :gutter="30">
          <el-col :xs="24" :sm="12" :md="8" :lg="6">
            <el-form-item label="通知:">
              <el-input v-model="search.username" placeholder="请输入自定义名称" />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div style="text-align: right;">
        <el-button type="primary" @click="getList()">查询</el-button>
        <el-button @click="resetSearch()">重置</el-button>
      </div>
    </el-card>

    <!-- 表格区域 -->
    <el-table :data="tableData" stripe>
      <el-table-column prop="id" label="ID" width="70" />
      <el-table-column prop="shui.username" label="创建人" />
      <el-table-column prop="username" label="自定义名称" />
      <el-table-column prop="shouji" label="手机号" />
      <el-table-column prop="addr" label="地址" />
      <!-- <el-table-column prop="createdAt" label="创建时间" width="180" />
      <el-table-column prop="updatedAt" label="更新时间" width="180" /> -->

      
      <el-table-column label="操作" width="120" fixed="right">
        <template #default="scope">
          <div v-if="isAdmin == 1">
          <el-button link type="primary" size="small" @click="editItem(scope.row)">编辑</el-button>
          <el-popconfirm title="确定要删除吗?" @confirm="deleteItem(scope.row.id)">
            <template #reference>
              <el-button link type="primary" size="small">删除</el-button>
            </template>
          </el-popconfirm>
        </div>
        </template>
      </el-table-column>


    </el-table>
    <!-- 分页 -->
    <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange"
      layout="sizes, total, prev, pager, next" :total="totalNum" :currentPage="search.pageNum"
      :pageSize="search.pageSize">
    </el-pagination>
  </el-card>
  <!-- 新增或编辑的抽屉 -->
  <sDrawer v-model="visible" :title="form.id ? '编辑通知' : '添加通知'" size="35%" :close-on-click-modal="false">

    <el-form :model="form" label-width="80px" ref="ruleFormRef">
      <el-form-item label="游客:">
        <el-select v-model="form.shui_id" clearable placeholder="请选择">
                <el-option
                  v-for="item in mjdata"
                  :key="item.id"
                  :label="item.username"
                  :value="item.id">
                </el-option>
    </el-select>
      </el-form-item>
    </el-form>

      <el-form :model="form" label-width="80px" ref="ruleFormRef">
      <el-form-item label="名称:">
        <el-input v-model="form.username" />
      </el-form-item>
    </el-form>
    <el-form :model="form" label-width="80px" ref="ruleFormRef">
      <el-form-item label="手机:">
        <el-input v-model="form.shouji" />
      </el-form-item>
    </el-form>
    <el-form :model="form" label-width="80px" ref="ruleFormRef">
      <el-form-item label="地址:">
        <el-input v-model="form.addr" />
      </el-form-item>
    </el-form>

    <template #footer>
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="saveData()">确定</el-button>
    </template>
  </sDrawer>
</template>

<script>
import sDrawer from "@/components/s-drawer/s-drawer.vue"
export default {
  components: {
    sDrawer,
  },
  watch: {
    visible(value) {
      if (!value) {
        this.form = {}
      }
    }
  },
  data() {
    return {
      form: {
        id: '',
      },
      uploadData: {
        abcd:2,
        // dfr: this.form.id
      },
      xydata: [],
      visible: false,
      tableData: [],
      totalNum: 100,
      search: {
        pageNum: 1,
        pageSize: 10,
        // token: "",
      },
      fileList: [{name: 'food.jpeg', url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'}, {name: 'food2.jpeg', url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'}]
    };
  },
  created() {
    // this.search.token = localStorage.getItem("token");
    this.getList();
    this.getmj();
    this.isAdmin = localStorage.getItem("isAdmin");
  },
  methods: {
    async getList() {
      this.$api.gethtdz(
        this.search
        ).then(res=>{
            if (res.data.code === 200){
              this.tableData = res.data.data;
              this.totalNum = res.data.zs
            }
        })
    },
    async saveData() {
      if (this.form.id) {
        this.$api.updatehtdz(this.form).then(res=>{
            if (res.data.code === 200){
              this.$message.success(res.data.message)
              this.getList()
              this.visible = false
            }
        })
      } else {
        this.$api.createhtdz(this.form).then(res=>{
            if (res.data.code === 200){
              this.$message.success(res.data.message)
              this.getList()
              this.visible = false
            }
        })
      }

 
    },
    async deleteItem(id) {
      this.$api.deletehtdz({id:id}).then(res=>{
            if (res.data.code === 200){
              this.$message.success(res.data.message)
              this.getList()
            }
        })
    },
    // 买家接口
    async getmj() {
      this.$api.gethtgm(
        this.search
        ).then(res=>{
            if (res.data.code === 200){
              this.mjdata = res.data.data;
            }
        })
    },

    // 每页条数改变时触发 选择一页显示多少行
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
      this.search.pageSize = val;
      this.getList();
    },
    // 当前页改变时触发 跳转其他页
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
      this.search.pageNum = val;
      this.getList();
    },
    resetSearch() {
      let search = {
        pageNum: this.search.pageNum,
        pageSize: this.search.pageSize,
      };
      this.search = search;
      this.getList();
    },
    editItem(row) {
      this.form = this.$deepClone(row)
      this.visible = true
    },


    // 照片文件超出个数限制时的钩子
    handleExceed(files, fileList) {
      this.$notify.warning({
      title: '警告',
      message: `只能选择 ${this.limitNum} 个文件，当前共选择了 ${files.length + fileList.length} 个`
      })
    },
    // 上传照片文件之前的钩子
    handleBeforeUpload(file) {
      const size = file.size / 1024 / 1024
          if (size > 1) {
            this.$notify.warning({
            title: '警告',
            message: '图片大小必须小于1M'
          })
      }
    },
    handleSuccess1(res) {
        console.log(res.data,'777777777777777777777777777777777777777')
        this.form.img_url = res.data.file
        this.dialogImageUrl = ''
        this.$notify({
            title: '通知',
            message: '上传照片成功~',
            type: 'success',
            duration: 5000
      })
    },
  //   handleHttprequest(params) {
  //   const formData = new FormData()
  //   formData.append('file', params.file)
  //   console.log("ddddddddddddddddddddddddddd")
  //   console.log(this.form)
  //   formData.append('id', this.form.id)
  //   // axios的二次封装
  //   this.$request({
  //     url: 'http://127.0.0.1:8000/img_upload/',
  //     method: 'post',
  //     headers: {
  //       'Content-Type': 'multipart/form-data',
  //     },
  //     data: formData
  //   }).then((res) => {
  //     this.$message({ type: 'success', message: '上传成功' })
  //     params.onSuccess(res)
  //   }).catch(() => {
  //     this.$message({ type: 'error', message: '上传失败' })
  //     params.onError()
  //   })
  // }

  },
};
</script>

<style scoped>
.el-pagination {
  margin-top: 10px;
}

.el-row {
  margin-bottom: 20px;
}

.el-row:last-child {
  margin-bottom: 0px;
}
</style>